#ifndef _SRC_JPG
#define _SRC_JPG
#include "usb_type.h"

#define SBUF_SIZE	10195
extern const u8 sbuf[SBUF_SIZE];		// һ֡320*240��С��jpgͼ��


#endif
